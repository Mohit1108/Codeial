const express = require('express');


const router = express.Router();

const homeController = require('../controllers/home_controller')
console.log("Router Loaded!")


router.get('/', homeController.home);
router.use('/users', require('./users'));
router.use('/login', require('./users'));
router.use('/register', require('./users'));
//  FOr any further routers, access from here
//  Router.use('/routerName', require('./routerFile'));

router.get('/logout', (req, res) => {
res.clearCookie('user_id');
return res.redirect('/users/login');
});

module.exports = router;


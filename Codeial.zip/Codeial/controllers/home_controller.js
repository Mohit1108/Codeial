module.exports.home = function(req, res){
    // return res.end('<h1> Express is up for Codieal!');
    return res.render('home',{
        title : "Home"
    });
}
const User = require('../models/user');

module.exports.profile = function (req, res) {
    // res.end('<h1> User Profile </h1>');
    if (req.cookies.user_id) {

        User.findById(req.cookies.user_id, function (err, user) {
            if (err) {
                console.log("Profile is Not visible until login: ")
                return;
            }
            if (user) {
                return res.render('user_profile', {
                    title: 'User Profile',
                    user: user
                });

            }
            else {
                return res.redirect('/users/login')

            }
        });


    }
    else {
        return res.redirect('/users/login')
    }








    // return res.render('user_profile', {
    //     title: 'User Profile'
    // })
}


//  Register Page 


module.exports.register = function (req, res) {
    // res.end('<h1> User Profile </h1>');
    return res.render('register', {
        title: 'Register Page'
    })
}


//  Login Page
module.exports.login = function (req, res) {
    // res.end('<h1> User Profile </h1>');
    return res.render('login', {
        title: 'Login Page'
    })
}

// Get the SignUp Data 
module.exports.create = function (req, res) {
    if (req.body.password != req.body.confirm_password) {
        return res.redirect('back');
    }
    User.findOne({ email: req.body.email }, function (err, user) {
        if (err) {
            console.log("Error in Finding User in Signing Up : ")
            return;
        }

        if (!user) {
            User.create(req.body, function (err, user) {
                if (err) {
                    console.log("Error in Creating User While Signing Up : ");
                    return;
                }
                return res.redirect('/users/login');
            })
        }
        else {
            return res.redirect('back');
        }

    })
}

// Sign in & Create a Session for the User
module.exports.createSession = function (req, res) {

    // Steps to authenticate
    // Find the User
    User.findOne({ email: req.body.email }, function (err, user) {
        if (err) {
            console.log("Error in Finding User in Signing Up : ")
            return;
        }


        // Handle User found
        if (user) {

            // Handle password which dont match
            if (user.password != req.body.password) {
                return res.redirect('back');
            }

            // handle session creation
            res.cookie('user_id', user.id);
            return res.redirect('/users/profile');


        }
        else {
            // handle user not found
            return res.redirect('back')

        }




    });







}

const express = require('express');
const cookieParser = require('cookie-parser');
const expressLayout = require('express-ejs-layouts');
const db = require('./config/mongoose');

const app = express();
const port = 8000;



app.use(express.urlencoded());

app.use(cookieParser());

app.use(express.static('./assets'));
app.use(expressLayout);
// Extract style & Scripts from sub pages in to the layouts
app.set('layout extractStyles', true);
app.set('layout extractScripts', true);

//  Use Express Router

app.use('/', require('./routes'));


// Set Up the View Engine
app.set('view engine', 'ejs');
app.set('views', './views');



app.listen(port, function(err){
    if (err){
        console.log(`Error in Running the Server: ${err}`);
        return;
    }
            console.log(`Server is Running on port: ${port}`)

})